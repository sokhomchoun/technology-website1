> Pull Requests are welcome. But v2 of Lightbox is in Maintenance Mode. 
> No new features are planned. See the [Roadmap](https://github.com/lokesh/lightbox2/blob/master/ROADMAP.md).
> 
> PRs submitted will still be reviewed and kept open for others to utilize.
